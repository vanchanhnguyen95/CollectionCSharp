﻿namespace TasksApi.Responses
{
    public class SignupResponse : BaseResponse
    {
        public string Email { get; set; }
    }
}
