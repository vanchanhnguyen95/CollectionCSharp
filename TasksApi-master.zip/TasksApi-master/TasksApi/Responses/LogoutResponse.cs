﻿namespace TasksApi.Responses
{
    public class LogoutResponse : BaseResponse
    {
    }
}
