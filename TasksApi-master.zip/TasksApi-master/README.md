# TasksApi
Updated to .NET 7, this is a simple API built in ASP.NET Core Web API, connecting SQL Server Express database with EF Core and using JWT-based authentication with refresh tokens

You can find the tutorial for this project in my blog:
http://codingsonata.com/apply-jwt-access-tokens-and-refresh-tokens-in-asp-net-core-web-api/
