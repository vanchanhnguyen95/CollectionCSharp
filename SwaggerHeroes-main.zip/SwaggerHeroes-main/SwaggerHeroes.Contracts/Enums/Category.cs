﻿namespace SwaggerHeroes.Core.Enums
{
    public enum Category
    {
        Anime,
        Comic,
        History,
        Mythology
    }
}