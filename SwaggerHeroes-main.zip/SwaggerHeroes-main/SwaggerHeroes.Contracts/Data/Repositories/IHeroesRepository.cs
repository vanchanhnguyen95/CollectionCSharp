using SwaggerHeroes.Core.Data.Entities;

namespace SwaggerHeroes.Core.Data.Repositories
{
    public interface IHeroesRepository : IRepository<Hero>
    {
    }
}