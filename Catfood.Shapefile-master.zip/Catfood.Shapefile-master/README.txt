See ShapefileDemo for a sample command line application that uses 
Catfood.Shapefile.dll.