﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetCoreWebAPiDemo.ViewModels
{
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }
        public string Messsage { get; set; }
    }
}
